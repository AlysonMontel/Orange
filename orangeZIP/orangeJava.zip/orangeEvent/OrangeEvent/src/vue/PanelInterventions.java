package vue;

public class PanelInterventions extends PanelPrincipal
{
    public PanelInterventions()
    {
        super("Gestion des interventions");
    }
}
