package vue;

public class PanelTechniciens extends PanelPrincipal
{
    public PanelTechniciens()
    {
        super("Gestion des techniciens");
    }
}
