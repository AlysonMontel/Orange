<h3>Ajout d'un technicien</h3>
<form action="" method="post">
    <table>
        <tr>
            <td>Nom du technicien</td>
            <td><input type="text" name="nom"></td>
        </tr>
        <tr>
            <td>Prénom du technicien</td>
            <td><input type="text" name="prenom"></td>
        </tr>
        <tr>
            <td>Spécialité</td>
            <td><input type="text" name="specialite"></td>
        </tr>
        <tr>
            <td>Date embauche</td>
            <td><input type="date" name="dateEmbauche"></td>
        </tr>
        <tr>
            <td> </td>
            <td>
                <input type="reset" name="Annuler" value="Annuler">
                <input type="submit" name="Valider" value="Valider">
            </td>
        </tr>
    </table>
</form>