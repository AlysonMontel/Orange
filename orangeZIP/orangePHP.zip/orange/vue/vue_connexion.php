<img src="image/orange.png" alt="" height="200" width="200">
<h1>Connexion à l'intranet Orange</h1>

<form action="" method="post">
    <table>
        <tr>
        <td>Email</td>
        <td><input type="text" name="email"></td>
        </tr>
        <tr>
            <td>Mot de Passe</td>
            <td><input type="password" name="mdp"></td>
        </tr>
        <tr>
            <tr></tr>
            <td><input type="submit" name="seConnecter" value="Connexion"></td>
        </tr>
    </table>
</form>